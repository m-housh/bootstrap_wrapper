Bootstrap Wrapper
=================

This is a python library that adds bootstrap capabilities to dominate.  Use at your own risk...  Only tested and used with python 3.5 not sure of compatablity with other python versions.

This is heavily inspired by Flask-Nav and Flask-Bootstrap.

While I'm a newbie to web development and my day job is Heating and Air Conditioning (far from an experienced programmer) I have quickly realized how much I dislike writing and reading html, as well as reading and writing macros for Jinja2.  Which is when I found the dominate library (which I **love**).  I like being able to make class based documents (that I'm using in a Flask application).

This is a work in progress so it is possible that I may break some tests as I'm using this in a different project and often come across tweaks that need to be made to the source code.  I'm sure there are plenty of things that could be better in this package, but I do use it on an almost daily basis while trying to develop an intranet site for my company.

I have not added any licenses or copyrights anyone is free to use/hack or do whatever they like with this.

This is not an offical python package so to use you should clone it into your project.

To Use - Clone into your project directory
------------------------------------------
```
git clone https://github.com/m-housh/bootstrap_wrapper.git
pip install dominate # python dependency
```
